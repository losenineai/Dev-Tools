package jadx.samples.otherpkg;

public class C {
	public static class E {

	}
}
